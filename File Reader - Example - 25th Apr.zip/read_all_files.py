import os

p  = os.listdir('E:\Sandbox\Python - AI')
#print(p)

#total file count
c = 0
#get count of all .txt file
tc = 0

for f in p:
    print(f)
    c +=1


    if f[-3:] =='txt':
        tc +=1
        

print ('no of files ',c)

print(tc)
