import os

path ='E:\Sandbox\Python - AI'
p  = os.listdir(path)


w = open('E:\Sandbox\output.txt','w')

for f in p:
    if f[-3:]  =='txt':
        print (f,'-------------data -------------')
        d = open(path+'\\'+f)
        #print(d.read())
        w.write(d.read())

w.close()

