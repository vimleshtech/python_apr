#take input from user
name = input('enter name :') #read string
eid = int(input('enter eid :')) # read string and convert to int
basic = int(input('enter basic sal :'))

#Compute
hra = basic*.40  #40% of basic
da = basic*.30  #30% of basic

monthly = basic+hra+da
ysal = monthly*12


#print / show output
print('name is :',name)
print('employee id is :',eid)
print('montyly sal is :',monthly)
print('yearly  sal is :',ysal)




      



