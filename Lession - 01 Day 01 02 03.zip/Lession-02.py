#take input 
name = input('enter name :')
sid  = input('enter id :')
hs = input('enter mark in hindi :')
es = input('enter mark in eng :')
cs = input('enter mark in computer :')
ms = input('enter mark in math :')


#print(type(cs))

#expression  # convert the data to int before compute 
total = int(hs) + int(es) + int(ms) + int(cs)
avg = total / 4

#output
print('name is ',name)
print('id is ',sid)
print('total mark ',total)
print('avg score ',avg)

#print grade
if avg>80:
     print('A')
elif avg>60:
     print('B')
elif avg>40:
     print('C')
else:
     print('D')

     

