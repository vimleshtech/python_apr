#WAP to input marks in five subjects of a student and calculate the division according to the following conditions:
		#Percentage				Division
		#>=60					First
		#50-59					Second
		#40-49					Third
		#<40					Fail
e=int(input("english marks"))
h=int(input("hindi marks"))
m=int(input("maths marks"))
sc=int(input("science marks"))
c=int(input("computer marks"))
percent=((e+h+m+sc+c)/500)*100
print("percentage is ",percent)
if percent>=60:
      print("first division")
elif percent>=50 and percent<=59:
     print("second division")
elif percent>=40 and percent<=49:
     print("third division")
else:
     print("fail")
