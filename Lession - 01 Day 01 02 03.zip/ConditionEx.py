#if condition
amt = int(input('enter sales amount :'))

tax = 0

if amt > 1000:
     tax = amt *.18 # 18% of sales amt
   
#get total
total = amt+ tax
print('total amt ',total)

###########################
##ii. if else condition

tax = 0

if amt > 1000:
     tax = amt *.18 # 18% of sales amt
else:
     tax = amt *.05 #05% of sales amt

total = amt+ tax
print('total amt ',total)


#iii. if elif elif elif .... else /ladder if else
tax = 0

if amt >= 10000:
     tax = amt *.18 # 18% of sales amt
elif amt >= 5000 : #and amt < 10000:
     tax = amt *.12 # 12% of sales amt
elif amt >= 1000:
     tax = amt *.05 # 5% of sales amt
else:
     tax = amt *.02 # 5% of sales amt
     
     
total = amt+ tax
print('total amt ',total)







