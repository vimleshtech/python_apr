
# input 4 vARIABLES
a=input('a')
b=input('b')
c=input('c')
d=input('d')

a = int(a)
a = a*a*a

b = int(b)
b = b*b*b

c  = int(c)
c = c*c*c


d = int(d)
d = d*d*d

if a+b+c==d:
     print('condition match')
else:
     print('condition not match')
     



