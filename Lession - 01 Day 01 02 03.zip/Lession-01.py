#declare the variable
"""
name ='raman sinha'
hs =88
es =90
ms =89

total = hs+es+ms

print(total)

"""
