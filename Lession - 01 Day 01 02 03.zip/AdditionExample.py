# comment line 

#input() - is inbuilt function, default input typs is string
#python does allocate memory automatically
a =1 # int
a ='sshs' #str
a ="sjhshs" #str
a = True # bool
a= [111,222,333,44] #list

 

n1  = input('enter data ')
n2 = input('enter data ')


print(type(n1)) #type(data) - return data type
print(type(n2)) 

#int(data) - convert string to int


#expression 
n = int(n1)+ int(n2)

#output
print('sum of two numbers ',n)
