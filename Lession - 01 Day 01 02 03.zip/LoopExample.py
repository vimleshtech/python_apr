
'''
List Operation:
     -list is mutable(data can be modifed)
Example:
     a =[111,222,33,444,'raman',male']
     -List index start from 0 index
     -last index of list will be len - 1 
     -There are following inbuilt methods

     len(a) -return count of element
     max(a)  -return highest value
     min(a) - return lowest value
     sum(a) - return total

     a.append(data) -add new value after last index
     a.pop()     - remove from last
     a.insert(index,data)  --add new value at given position
     a.remove(data)   - find value and remove if present
     a.sort()   -- range data in ascending orde / sorting
     slicer      -- read element by index
               a[1]  -- return 2nd element
               a[0:3]  --return to 0 to 2
               a[-1]    --read last one 


Tuple Operation:
     -tuple is imutable (read only)
Example:
     t =(11,222,333,4)
     Methods:
          len(t)
          max(t)
          min(t)
          sum(t)
          

Loop: is iterator or repeation of statement
Example:
      1 2 3 ... 100
      100 99 .... 1
Fundamental of loop:
     -init                    :   1   100
     -condition               :   100  1
     -increment/decrement     :   +1   -1 
There are following types of loop:
-while loop 
-for loop 


      
     
'''
data = [111,222,333,444,432,2,1]


#while loop
i =1
while i<100:
     print(i)
     i = i+1 # i+=1   # i++ doesn't support


#print reverse
i =100
while i>0:
     print(i)
     i-=1


#for loop
for i in range(1,100):   #from 1 to <100 , default incrementer is 1
     print(i)


#print all odd numbers between 1 to 30
for i in range(1,30,2):
     print(i)
     
##list
l =[11,22,2,23,4,4,5]


for x in l:
     print(x)
     





     
     
     
     

     



     





