a=[]
for i in range(0,15):
     d = int(input('enter data for list 1  :'))
     a.append(d)
     
e=int(input("write a element you want to find"))

c = 0
for i in range(0,15):
     if e == a[i]:
      c=c+1
      

print(c)
