#iv. nested if else / if inside if condition


a = int(input('enter no :'))
b = int(input('enter no :'))
c = int(input('enter no :'))

#nested if else 
if a> b:
     if a>c:
          print('a is greater ')
     else:
          print('b is greaer ')

else:
     if b>c:
          print('b is greater')
     else:
          print('c is greater ')

          
#if elif elfi else .... 
if a>b and a>c:
     print('a is greater ')
elif b>a and  b>c:
     print(' b is greater ')
else:
     print('c is greater ')

     


     
     



