#WAP to input the salary of a person and calculate the hra and da according to the following conditions:
		

salary=int(input("salary of a person"))

if salary>=5000 and salary<10000:

     hra=salary*.01
     da =salary*.05

     print ("hra ",hra)
     print("da",da)

elif salary>=10001 and salary<15000:

     hra= salary *.15
     da =salary*.8

     print ("hra ",hra)
     print("da",da)




