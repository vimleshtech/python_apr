#WAP to subtract two arrays of the same size
a=[]
b=[]
for i in range(0,5):
     d = int(input('enter data for list 1  :'))
     a.append(d)

for i in range(0,5):
     d = int(input('enter data for list 2  :'))
     b.append(d)


for i in range(0,5):
     print(a[i] - b[i])

print(a)
print(b)


          
