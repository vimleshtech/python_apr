
unit=int(input("your electricity units "))
if unit<=100:
     bill=100*.40
     print("your bill is",bill)
elif unit>100 and unit < 200:
     bill=100*.40 + (unit-100)*.50
     print(" your bill is ", bill)
else:
     unit>300
     bill=100*.40 + 100*.50 + (unit - 200)*.60
     print("your bill is",bill)
